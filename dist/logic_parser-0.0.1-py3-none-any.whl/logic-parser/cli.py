#!/usr/bin/env python

import argparse
from lark import Lark
from pathlib import Path

argparser = argparse.ArgumentParser()
argparser.add_argument("expr")
argparser.add_argument(
    "--grammar-file",
    "-g",
    help="absolute or relative path (from cwd) to grammar file",
    default="./grammar",
)


def main(expr: str, grammar: str):
    tree = parse(expr, grammar)
    print(tree.pretty())


def parse(expr: str, grammar: str):
    parser = Lark(grammar)
    return parser.parse(expr)


if __name__ == "__main__":
    args = argparser.parse_args()
    grammar_path = Path(args.grammar_file)
    with open(grammar_path) as fp:
        grammar = fp.read()

    main(args.expr, grammar)
