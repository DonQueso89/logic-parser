from logic_parser import parse
import pytest

pytest.mark.parametrize(
    "expr",
    [
        ("p & q",),
        ("(p & q)",),
        ("p | q",),
        ("(p | q)",),
    ],
)


def test_parser(expr):
    pass
